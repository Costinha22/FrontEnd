import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.Scanner;

public class gamestart {


    //*********************Funções*************************

    public static void exibirjogos() throws FileNotFoundException {

        File ficheiro = new File("dados/GameStart_V2.csv");

        Scanner leitor = new Scanner(ficheiro);
        String [] jogosDisponiveis = new String[165];

        String nomeJogo = "";    int index = 0;
        leitor.nextLine();

        while (leitor.hasNextLine()) {
            String linha = leitor.nextLine();

            String[] conteudo = linha.split(";");        nomeJogo = conteudo[7];

            boolean encontrado = false;

            for (int i = 0; i < jogosDisponiveis.length; i++) {
                if (nomeJogo.equals(jogosDisponiveis[i])) {encontrado = true;
                    break;
                }
            }
            if (!encontrado) {
                jogosDisponiveis[index] = nomeJogo;
                index++;
            }
        }
        System.out.println("Os jogos disponíveis são: \n");
        for (int i = 0; i < index; i++) {
            System.out.println(jogosDisponiveis[i]);
        }
    }


    public static void menuCliente() throws FileNotFoundException {

        Scanner inputUser = new Scanner(System.in);
        String opcao = "";

        do {
            System.out.println("1. Registo de novo cliente");
            System.out.println("2. Verificar vagas de estacionamento disponíveis");
            System.out.println("3. Verificar quais os jogos disponíveis");
            System.out.println("4. Porcurar jogos por Editora");
            System.out.println("5. Voltar ao menu principal");
            opcao = inputUser.next();

            switch (opcao) {
                case "1":
                    registocliente();
                    break;

                case "2":
                    verificarVagasEstacionamento();
                    break;

                case "3":
                    exibirjogos();
                    break;

                case "4":
                    System.out.println("em desenvolvimento");
                    return;
                case "5":
                    System.out.println("Voltar ao menu principal");
                default:
                    System.out.println("Opção inválida");

            }
        }
        while (!opcao.equals("5"));
    }


    public static void PedirPassword() throws FileNotFoundException {
        Scanner inputDoUser =  new Scanner(System.in);

        String password= "admin";
        String comparar = "";


        do{
            System.out.println("Insira a sua palavra-passe");
            comparar = inputDoUser.next();
            if (comparar.equals(password)){
                menuAdmin();
                System.out.println("Menu Admin");
            }

        }while (!password.equals(comparar));

    }


    public static void registocliente() throws FileNotFoundException {

        Scanner inputUser = new Scanner(System.in);
        String opcao;

                    // Código para registar um novo cliente
                    System.out.print("Digite seu nome: ");
                    String nome = inputUser.next();
                    System.out.print("Digite seu contacto: ");
                    String contato = inputUser.next();
                    System.out.print("Digite seu e-mail: ");
                    String email = inputUser.next();

                    // Exibe mensagem de confirmação
                    System.out.println("\nRegisto efetuado com sucesso!");

                    System.out.println("Dados do Cliente:");
                    System.out.println("Nome: " + nome);
                    System.out.println("Contacto: " + contato);
                    System.out.println("E-mail: " + email);

                    File ficheiroNovo = new File("dados/dadoscliente.txt");

                    //Máquina para escrever no meu ficheiro
                    PrintWriter maquinaEsrever = new PrintWriter(ficheiroNovo);


                    //Conteudo do ficheiro - mensagem
                    String minhaMensagem = "\nNome: " + nome + "\nContato: " + contato + "\nEmail: " + email;


                    //Impirmir no ficheiro
                    maquinaEsrever.println(minhaMensagem);

                    //Fechar a máquina
                    maquinaEsrever.close();
    }


    public static void menuAdmin() throws FileNotFoundException {
        Scanner inputUser = new Scanner(System.in);
        String opcao = "";

        do {
            System.out.println("1. Exibir dados do arquivo");
            System.out.println("2. Total de vendas");
            System.out.println("3. Calcular lucros");
            System.out.println("4. Exibir informações clientes");
            System.out.println("5. Exibir qual jogo mais caro e quais os clientes que o compraram");
            System.out.println("6. Exibir o melhor cliente da loja");
            System.out.println("7. Voltar ao menu principal");

            opcao = inputUser.next();

            switch (opcao) {
                case "1":
                    exibirconteudo();

                    break;

                case "2":

                    break;

                case "3":

                    break;

                case "4":

                    break;

                case "5":
                    break;
                case "6":

                    System.out.println("Opção inválida");
                case "7":
                    System.out.println("Voltar ao menu principal");
                    return;

                default:
                    System.out.println("Opção inválida");

            }
        }
        while (!opcao.equals("7"));
    }

    public static void exibirconteudo() throws FileNotFoundException {
        // Caminho para o ficheiro CSV
        File ficheiro = new File("dados/GameStart_V2.csv");
        Scanner leitor = new Scanner(ficheiro);

        // Ler e mostrar cada linha do arquivo
        while (leitor.hasNextLine()) {
            System.out.println(leitor.nextLine());
        }
    }



    // Métudu para verificar vagas de estacionamento
    public static void verificarVagasEstacionamento() {
        System.out.println("A verificar vagas de estacionamento disponíveis...");

        System.out.print("As vagas disponíveis são: ");
        for (int n = 1; n <= 15; n++) {
            int numeroTriangular = (n * (n + 1)) / 2; // Cálculo do número triangular

            // Verifica se o número triangular é um múltiplo de 5
            if (numeroTriangular % 5 == 0 && numeroTriangular <= 121) {
                System.out.print(numeroTriangular + " "); // Mostra as vagas disponíveis
            }
        }

    }


    //**************CódigodoMain**************************

    public static void main (String[]args) throws FileNotFoundException {

        //Indicar o caminho para o ficheiro logo
        File caminhologo = new File("dados/logo.txt");


        //Ler o ficheiro
        Scanner logo = new Scanner(caminhologo);
        Scanner inputUser = new Scanner(System.in);

        String selecaoUser = "";

        //Ciclo para ler as linhas do txt e printar na consola
        while (logo.hasNextLine()) {
            System.out.println(logo.nextLine());
        }

        //Ciclo para mostrar opções de escolha dos menus cliente e admin
        do {
            System.out.println("opção 1 - admin");
            System.out.println("opção 2 - cliente");
            System.out.println("opção 3 - sair");

            selecaoUser = inputUser.next();

            //
            switch (selecaoUser) {

                case "1":
                    PedirPassword();
                    break;
                case "2":
                    menuCliente();
                    break;
                case "3":
                    System.out.println("Sair");
                default:
                    System.out.println("\nEscolha uma das opções sugeridas do menu");
            }

        } while (!selecaoUser.equals("3"));


    }


}
